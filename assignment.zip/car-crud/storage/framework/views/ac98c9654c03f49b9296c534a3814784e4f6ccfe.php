<!DOCTYPE html>
<html>
  <head>
    <title>Team Members</title>
  </head>
  <body>
      <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('teams')); ?>">View All Teams</a></li>
    </ul>
      <h2>Add Members in <?php echo e($team->team_name); ?></h2>
<?php echo Form::open([
    'route' => 'team_members.store'
]); ?>

<input type="hidden" name="team_id" value="<?php echo e($team->id); ?>"/>
<div class="form-group">
    <?php echo Form::label('member_name', 'Member Name:', ['class' => 'control-label']); ?>

    <?php echo Form::text('member_name', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('member_id', 'Member ID:', ['class' => 'control-label']); ?>

    <?php echo Form::text('member_id', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('password', 'Password:', ['class' => 'control-label']); ?>

    <?php echo Form::password('password', null, ['class' => 'form-control']); ?>

</div>

<?php echo Form::submit('Register New Member', ['class' => 'btn btn-primary']); ?>


<?php echo Form::close(); ?>


  </body>
</html>
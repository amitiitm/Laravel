<!-- resources/views/login.blade.php -->

<form method="POST" action="/team/login1">
    <?php echo csrf_field(); ?>


   <div> 
       Login Type
    <?php echo Form::select('size', array('t' => 'Team', 'tm' => 'TeamMember')); ?>

   </div>
    
    <div>
        Manage ID:
        <input type="text" name="text" value="">
    </div>

    <div>
        Password
        <input type="password" name="password" id="password">
    </div>

    <div>
        <button type="submit">Login</button>
    </div>
</form>
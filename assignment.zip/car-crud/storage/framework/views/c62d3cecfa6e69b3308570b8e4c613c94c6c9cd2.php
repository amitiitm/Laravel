<!DOCTYPE html>
<html>
  <head>
    <title>Cars</title>
  </head>
  <body>
      <a href="/cars/create" class="btn btn-info">Add Car</a>
  <?php foreach($cars as $car): ?>
    <h3>Make : <?php echo e($car->make); ?></h3>
    <p>Model : <?php echo e($car->model); ?></p>
    <p>
        <a href="<?php echo e(route('cars.show', $car->id)); ?>" class="btn btn-info">View Car</a>
        <a href="<?php echo e(route('cars.edit', $car->id)); ?>" class="btn btn-primary">Edit Car</a>
    </p>
    <hr>
  <?php endforeach; ?>
  </body>
</html>
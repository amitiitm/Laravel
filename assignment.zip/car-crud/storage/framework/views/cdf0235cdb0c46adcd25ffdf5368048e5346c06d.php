<!DOCTYPE html>
<html>
  <head>
    <title>Registered Teams</title>
  </head>
  <body>
      <a href="/teams/create" class="btn btn-info">Add New Team</a>
      <h2>Already Registered Teams</h2>
  <?php foreach($teams as $team): ?>
    <h3>Name : <a href="/team_members/create/<?php echo e($team->id); ?>"><?php echo e($team->team_name); ?></a></h3>
  <?php endforeach; ?>
  </body>
</html>
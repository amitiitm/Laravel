<!DOCTYPE html>
<html>
  <head>
    <title>Cars</title>
  </head>
  <body>
      <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('cars')); ?>">View All Cars</a></li>
    </ul>
<?php echo Form::open([
    'route' => 'cars.store'
]); ?>


<div class="form-group">
    <?php echo Form::label('make', 'Make:', ['class' => 'control-label']); ?>

    <?php echo Form::text('make', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('model', 'Model:', ['class' => 'control-label']); ?>

    <?php echo Form::text('model', null, ['class' => 'form-control']); ?>

</div>

<?php echo Form::submit('Create New Car', ['class' => 'btn btn-primary']); ?>


<?php echo Form::close(); ?>


  </body>
</html>
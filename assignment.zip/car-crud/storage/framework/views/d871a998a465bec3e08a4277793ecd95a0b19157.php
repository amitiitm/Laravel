<!DOCTYPE html>
<html>
  <head>
    <title>Teams</title>
  </head>
  <body>
      <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('teams')); ?>">View All Teams</a></li>
    </ul>
<?php echo Form::open([
    'route' => 'teams.store'
]); ?>


<div class="form-group">
    <?php echo Form::label('team_name', 'Team Name:', ['class' => 'control-label']); ?>

    <?php echo Form::text('team_name', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('manager_id', 'Manager ID:', ['class' => 'control-label']); ?>

    <?php echo Form::text('manager_id', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('password', 'Password:', ['class' => 'control-label']); ?>

    <?php echo Form::password('password', null, ['class' => 'form-control']); ?>

</div>

<?php echo Form::submit('Register New Team', ['class' => 'btn btn-primary']); ?>


<?php echo Form::close(); ?>


  </body>
</html>
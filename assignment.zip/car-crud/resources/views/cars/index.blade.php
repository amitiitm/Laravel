<!DOCTYPE html>
<html>
  <head>
    <title>Cars</title>
  </head>
  <body>
      <a href="/cars/create" class="btn btn-info">Add Car</a>
  @foreach($cars as $car)
    <h3>Make : {{ $car->make }}</h3>
    <p>Model : {{ $car->model}}</p>
    <p>
        <a href="{{ route('cars.show', $car->id) }}" class="btn btn-info">View Car</a>
        <a href="{{ route('cars.edit', $car->id) }}" class="btn btn-primary">Edit Car</a>
    </p>
    <hr>
  @endforeach
  </body>
</html>
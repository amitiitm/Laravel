<!DOCTYPE html>
<html>
  <head>
    <title>Cars</title>
  </head>
  <body>
      <ul class="nav navbar-nav">
        <li><a href="{{ URL::to('cars') }}">View All Cars</a></li>
        <li><a href="{{ URL::to('cars/create') }}">Create a Car</a>
    </ul>

{{ Form::model($car, array('route' => array('cars.update', $car->id), 'method' => 'PUT')) }}

<div class="form-group">
    {!! Form::label('make', 'Make:', ['class' => 'control-label']) !!}
    {!! Form::text('make', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('model', 'Model:', ['class' => 'control-label']) !!}
    {!! Form::text('model', null, ['class' => 'form-control']) !!}
</div>

{!! Form::submit('update Car', ['class' => 'btn btn-primary']) !!}

{!! Form::close() !!}

  </body>
</html>
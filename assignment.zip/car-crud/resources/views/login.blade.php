<!-- resources/views/login.blade.php -->

<form method="POST" action="/team/login1">
    {!! csrf_field() !!}

   <div> 
       Login Type
    {!! Form::select('size', array('t' => 'Team', 'tm' => 'TeamMember')) !!}
   </div>
    
    <div>
        Manage ID:
        <input type="text" name="text" value="">
    </div>

    <div>
        Password
        <input type="password" name="password" id="password">
    </div>

    <div>
        <button type="submit">Login</button>
    </div>
</form>
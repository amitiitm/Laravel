<!DOCTYPE html>
<html>
  <head>
    <title>Team Members</title>
  </head>
  <body>
      <ul class="nav navbar-nav">
        <li><a href="{{ URL::to('teams') }}">View All Teams</a></li>
    </ul>
      <h2>Add Members in {{$team->team_name}}</h2>
{!! Form::open([
    'route' => 'team_members.store'
]) !!}
<input type="hidden" name="team_id" value="{{$team->id}}"/>
<div class="form-group">
    {!! Form::label('member_name', 'Member Name:', ['class' => 'control-label']) !!}
    {!! Form::text('member_name', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('member_id', 'Member ID:', ['class' => 'control-label']) !!}
    {!! Form::text('member_id', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('password', 'Password:', ['class' => 'control-label']) !!}
    {!! Form::password('password', null, ['class' => 'form-control']) !!}
</div>

{!! Form::submit('Register New Member', ['class' => 'btn btn-primary']) !!}

{!! Form::close() !!}

  </body>
</html>
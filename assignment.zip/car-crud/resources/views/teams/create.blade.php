<!DOCTYPE html>
<html>
  <head>
    <title>Teams</title>
  </head>
  <body>
      <ul class="nav navbar-nav">
        <li><a href="{{ URL::to('teams') }}">View All Teams</a></li>
    </ul>
{!! Form::open([
    'route' => 'teams.store'
]) !!}

<div class="form-group">
    {!! Form::label('team_name', 'Team Name:', ['class' => 'control-label']) !!}
    {!! Form::text('team_name', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('manager_id', 'Manager ID:', ['class' => 'control-label']) !!}
    {!! Form::text('manager_id', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('password', 'Password:', ['class' => 'control-label']) !!}
    {!! Form::password('password', null, ['class' => 'form-control']) !!}
</div>

{!! Form::submit('Register New Team', ['class' => 'btn btn-primary']) !!}

{!! Form::close() !!}

  </body>
</html>
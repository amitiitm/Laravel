<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Team;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Session;
class TeamController extends Controller
{
    public function index()
    {
      $teams = Team::all();
      return view('teams.index', array('teams' => $teams));
    }
    
    public function create()
    {
      return view('teams.create');
    }
    
    public function login1()
   {
// validate the info, create rules for the inputs
$rules = array(
    'manager_id'    => 'required', // make sure the email is an actual email
    'password' => 'required' // password can only be alphanumeric and has to be greater than 3 characters
);

// run the validation rules on the inputs from the form
$validator = Validator::make(Input::all(), $rules);

// if the validator fails, redirect back to the form
if ($validator->fails()) {
    return Redirect::to('login')
        ->withErrors($validator) // send back all errors to the login form
        ->withInput(Input::except('password')); // send back the input (not the password) so that we can repopulate the form
} else {

        $manager_id = Input::get('manager_id');
        $password = bcrypt(Input::get('password'));
        $team = Team::where('manager_id', '=', $manager_id)->firstOrFail();
    // attempt to do the login
    if (($team->password) == $password) {

        // validation successful!
        // redirect them to the secure section or whatever
        // return Redirect::to('secure');
        // for now we'll just echo success (even though echoing in a controller is bad)
        echo 'SUCCESS!';

    } else {        
        // validation not successful, send back to form 
        return Redirect::to('register');

    }

}
}
    
    public function store()
    {
        $rules = array(
            'manager_id'       => 'required|unique:teams|max:255',
            'team_name'      => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to('teams/create')
                ->withErrors($validator)
                ->withInput(Input::except('password'));
        } else {
            // store
            $team = new Team;
            $team->manager_id  = Input::get('manager_id');
            $team->team_name   = Input::get('team_name');
            $team->password = bcrypt(Input::get('password'));
            $team->save();

            // redirect
            Session::flash('message', 'Team Registered Successfully');
            return Redirect::to('teams');
        }
    }
    
    public function show($id)
    {
       $team = Team::find($id);
      return view('teams.show', array('team' => $team));
    }
    
    public function edit($id)
    {
        $team = Car::find($id);
        return view('teams.edit', array('team' => $team));
    }
    
     public function update($id)
    {
        $rules = array(
            'manager_id'       => 'required|unique:teams|max:255',
            'team_name'      => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to('teams/' . $id . '/edit')
                ->withErrors($validator)
                ->withInput(Input::except('password'));
        } else {
            // store
            $team = Team::find($id);
            $team->team_name = Input::get('team_name');
            $team->save();

            // redirect
            Session::flash('message', 'Successfully updated Team Profile');
            return Redirect::to('teams');
        }
    }
}

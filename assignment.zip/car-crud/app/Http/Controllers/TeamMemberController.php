<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Team;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Session;
class TeamMemberController extends Controller
{
   public function create($id)
    {
     $team = Team::find($id);
     return view('team_members.create', array('team' => $team));
    }
    
     public function store()
    {
        $rules = array(
            'member_id'       => 'required|unique:teams|max:255',
            'member_name'      => 'required'
        );
        $validator = Validator::make(Input::all(), $rules);

        // process the login
        if ($validator->fails()) {
            return Redirect::to('teams')
                ->withErrors($validator)
                ->withInput(Input::except('password'));
        } else {
            // store
            $team_member = new TeamMember;
            $team_member->member_id  = Input::get('member_id');
            $team_member->team_id  = Input::get('team_id');
            $team_member->member_name   = Input::get('member_name');
            $team_member->password = bcrypt(Input::get('password'));
            $team_member->save();

            // redirect
            Session::flash('message', 'Member Registered Successfully');
            return Redirect::to('teams');
        }
    }
}
